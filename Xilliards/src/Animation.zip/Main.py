from Animation import *
from CitedFunctions import *
from tkinter import *

run(1000, 500)
