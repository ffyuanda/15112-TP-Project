Xilliards by Shaoxuan Yuan

You should click on the screen (anywhere!) to display the cue stick.

The first time you press the space key, the force starts to count.
 
The second time you press the space key, the force released and you hit the cue ball!

Press r to restart.

If you don't hit any ball in a shot, you get a scratch! Then you click on the table to replace the ball!

-----------------------------------------------------------------------------------------------------------------
Needed modules:

NumPy scientific calculation package from https://numpy.org/.

Test mode:

You could easily toggle to test mode by change the data.testMode variable in Animation file, init function, to True.
Then there would only be one ball on the table!